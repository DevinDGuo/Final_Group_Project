#ifndef UTILITIES_H
#define UTILITIES_H

void global_sum(double* result, int rank, int size, double my_value);
char* toBinary(int n);

#endif /* UTILITIES_H */
